import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App';
// tempelkan code yang disiapkan dikolom instruksi dibawah
ReactDOM.render(<App />, document.getElementById('root'));